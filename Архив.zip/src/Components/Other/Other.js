import React from 'react'

function Other() {
    return (
        <div>
            Другой информации нет
        </div>
    )
}

export default Other