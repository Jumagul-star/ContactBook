import {combineReducers} from 'redux';
import UserReducer from './users/reducer'

export const rootReducer = combineReducers({
    UserReducer
})